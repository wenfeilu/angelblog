const mysql = require("mysql");

const db = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'root',
    port     : 8889,
    database : 'nodemysql'
  
  });
  
  db.connect((err) => {
    if(err) {
        throw err;
    }
    console.log('mysql connected.....');
  
  });

  module.exports = db;

  